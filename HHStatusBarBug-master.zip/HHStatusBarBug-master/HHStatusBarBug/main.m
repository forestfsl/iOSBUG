//
//  main.m
//  HHStatusBarBug
//
//  Created by caohuihui on 2016/12/12.
//  Copyright © 2016年 caohuihi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HHAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HHAppDelegate class]));
    }
}
